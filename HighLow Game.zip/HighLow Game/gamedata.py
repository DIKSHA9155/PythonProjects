game_data = [
    {
        'Name' : 'Cristiano Ronaldo',
        'FollowerCount' : 67000,
        'Description' : 'Footballer',
        'Country' : 'Portugal'
    },
    {
        'Name' : 'Narendra Modi',
        'FollowerCount' : 33000,
        'Description' : 'Prime Minister',
        'Country' : 'India'
    },
    {
        'Name' : 'Arijit Singh',
        'FollowerCount' : 89000,
        'Description' : 'Singer',
        'Country' : 'India'
    },
    {
        'Name' : 'Tom Cruise',
        'FollowerCount' : 55000,
        'Description' : 'Actor',
        'Country' : 'USA'
    }
]

logo = """
    __  ___       __             
   / / / (_)___ _/ /_  ___  _____
  / /_/ / / __ `/ __ \/ _ \/ ___/
 / __  / / /_/ / / / /  __/ /    
/_/ ///_/\__, /_/ /_/\___/_/     
   / /  /____/_      _____  _____
  / /   / __ \ | /| / / _ \/ ___/
 / /___/ /_/ / |/ |/ /  __/ /    
/_____/\____/|__/|__/\___/_/     
"""

vs = """
 _    __    
| |  / /____
| | / / ___/
| |/ (__  ) 
|___/____(_)
"""